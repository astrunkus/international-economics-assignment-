# Does Trade Openness Encourage Clean Energy Investment? Evidence from Emerging Markets

ECON F311 — International Economics

BITS Pilani, Pilani Campus

International public clean energy financing commitments, 2000–2023

Group 17

Ritik Yadav — 2024B3A30940

Sriansh Rajan — 2024B3A80901P

Nidhish Kumar Tyagi — 2024B3A80952P

Heet Jain — 2024B3A80929P

Jaivardhan Singh — 2024B3A40859P

12 October 2026

# Abstract

Does a more open economy attract more clean energy investment? Trade can lower equipment costs and widen access to technology and finance. It can also increase demand for fossil fuels. This report examines the question using annual data for fifteen selected emerging economies from 2000 to 2023. The outcome is international public financing commitments for clean energy, taken from UN Sustainable Development Goal indicator 7.a.1 and measured in constant 2023 US dollars per person. The measure covers public international commitments; domestic and private investment lie outside its coverage, and disbursements are recorded separately. World Bank data supply trade openness, income, FDI, and population. Pooled, random effects, and country and year fixed effects models are compared, alongside diagnostic and sensitivity checks. The baseline fixed effects estimate is positive: a ten percentage point increase in the previous year's trade ratio is associated with a 0.108 increase in log one plus financing per person. The country-clustered p-value is 0.012; the wild-cluster bootstrap gives 0.073. The estimate stays positive without China and in the pre-pandemic sample. It is not statistically significant when the sample starts in 2010, country trends are included, or first differences are used. A separate analysis also finds no clear link with solar and wind generation growth. The association is sensitive to the specification, and a causal effect remains unresolved. Policy analysis should examine specific equipment and financing channels before linking a higher overall trade ratio to more clean energy projects.

Keywords: trade openness; clean energy finance; emerging markets; panel data; renewable investment

# 1. Introduction

A renewable energy project can depend on several countries before it produces any electricity. Solar modules may be imported, turbine parts may come from foreign suppliers, and specialised engineering services may be sourced abroad. Trade can lower the cost of these inputs and give developers more choice. This is one reason to expect a link between openness and clean energy investment.

There are reasons the link may be weaker than it first appears. Trade can also support fossil fuel imports and energy-intensive manufacturing. Credit costs, electricity contracts, and grid access can still constrain a project even when equipment becomes cheaper. Public lenders may choose projects according to development needs or donor priorities. To examine the relationship, the financing measure must be clearly defined and lasting country differences must be separated from changes over time.

Antweiler et al. (2001) separate trade's environmental effects into scale, composition, and technique channels. Their evidence concerns pollution, which makes its relevance to renewable finance primarily theoretical. Copeland and Taylor (2004) situate trade and growth in the environmental literature. These frameworks suggest that aggregate openness combines competing mechanisms. Renewable-equipment reforms deserve separate examination.

This report brings together country-year financing data, tests its relationship with the previous year’s trade openness, and checks how the result changes under different assumptions. The data and calculations are retained so they can be examined. The contribution is the comparison across selected countries and specifications.

The available outcome is international public financing commitments for clean energy. A commitment records approved finance, with disbursement potentially following later. Domestic and purely private projects are largely outside the data. The analysis therefore answers a narrower version of the question in the title.

# 2. Literature Review

The environmental trade literature explains why the sign of the relationship is ambiguous. Antweiler et al. (2001) investigate pollution concentrations using scale, composition, and technique effects; their published abstract reports a net pollution-reducing result in their setting. This provides a framework for the possible mechanisms affecting the financing measure used here. Copeland and Taylor (2004) offer a broader review of trade, growth, and environmental outcomes. The direction of the renewable-investment response still needs empirical assessment.

Eyraud et al. (2013) study green investment and its determinants. The related IMF working paper summarises historical evidence from advanced and emerging economies and identifies growth, financing conditions, fuel prices, and policy instruments as relevant factors (Eyraud et al., 2011). This motivates income and financial-context controls. The working paper and journal article belong to the same research line, so they count as related evidence.

Polzin et al. (2015) examine public policy and renewable investment in an OECD panel. That setting differs from this emerging-market recipient-country analysis. It highlights the relevance of policy conditions, which country fixed effects can capture only when they are stable. Changing procurement rules, support schemes, and financing conditions remain possible omitted variables in the present design.

Ebaidalla (2024) directly connects taxation, technological innovation, trade openness, and renewable investment in its research question. Appiah-Otoo et al. (2025) examine governance, financial openness, and renewable investment in Africa. Financial openness is distinct from the goods-and-services trade ratio used here. These studies motivate attention to taxation, technological change, governance, and financing conditions. The comparison is limited to their research scope because their detailed empirical findings have yet to be checked against the full texts.

This study examines whether a within-country relationship appears in a public clean energy financing panel and whether it survives controls for trends, alternative periods, and inference with few countries. The outcome, selected sample, and reproducibility package distinguish this exercise from the cited studies. The selected financing measure and sensitivity analysis define the contribution.

# 3. Data and Methodology: Sources and Sample

The sample contains Brazil, China, India, Indonesia, Mexico, Türkiye, South Africa, Thailand, Malaysia, the Philippines, Viet Nam, Egypt, Morocco, Colombia, and Peru. It is a purposive selection spanning Latin America, Asia, and Africa. Viet Nam is included for regional coverage. Its coverage limits how far the findings can be generalised.

The analytical period is 2000–2023. World Bank data for 1999 provide the first preceding-year controls. The UN series also contains 2024 financing observations, but the main panel uses the period fixed during collection of the controls; those later observations are preserved in the raw responses and are not used. All 360 candidate observations are available for the main regression.

The dependent variable uses SDG indicator 7.a.1, series EG_IFF_RANDN. OECD and IRENA compile international public support for clean energy research and renewable energy production, including hybrid systems. The retrieved series records recipient-country commitments in millions of constant 2023 US dollars. Source footnotes identify donor-country deflators and exchange-rate conventions. No additional CPI conversion is applied.

The technology dimension ALL is selected once per country and year, with reporting type G. It is not added to its technology components, which would double count the flows. Each raw country response has 200 records: 25 years and eight technology categories. The main sample contains thirteen explicitly reported zero aggregate commitments. These zeros remain in the model; missing values are not converted into zeros.

The outcome covers public international financing commitments. Total domestic and private investment and actual expenditure require additional data. The current data source labels observations Nature = E; the source status is retained without relabelling them as audited project transactions. UN methodology and source footnotes are archived. Duplicate keys, pagination completeness, units, base period, technology filters, and sample inclusion are checked in the scripts.

# 3.1 Variables, Sources, and Rationale

The trade ratio records actual imports and exports. Tariff policy is a separate measure. Commodity prices, exchange rates, and changes in GDP can move the ratio even without a policy change. Values above 100% are possible because gross trade is compared with domestic value added. Dividing openness by ten makes its coefficient easier to read: it corresponds to a ten percentage point change.

Real income per person is measured in constant 2015 US dollars and enters in logarithms. Development can influence renewable demand, financing capacity, and eligibility for concessional support. FDI describes the wider financing context and includes sectors beyond renewable energy. Both controls are lagged by one year. Lagging reduces contemporaneous overlap; exogeneity remains an assumption requiring further evidence.

Population converts international commitments into comparable per-person amounts. Dividing by GDP would combine the outcome with another denominator and would require compatible real-price definitions. The principal model therefore uses per-person commitments. A total-finance specification with a population control checks whether this scale choice drives the result.

Table 1. Variables and data sources

| Variable | Definition / units | Source and rationale |

| --- | --- | --- |

| Clean energy finance | ln(1 + commitments in 2023 US$/person) | UN SDG 7.a.1; principal outcome |

| Trade openness | Exports plus imports / GDP × 100; lagged | WDI NE.TRD.GNFS.ZS; exposure |

| Real income/person | Natural logarithm; lagged | WDI NY.GDP.PCAP.KD; development |

| FDI inflows | Net inflows / GDP × 100; lagged | WDI BX.KLT.DINV.WD.GD.ZS; finance context |

| Population | Persons | WDI SP.POP.TOTL; scale adjustment |

| Country/year effects | Country intercepts; annual indicators | Stable heterogeneity/common shocks |

# 3.2 Data Transformations and Model Equation

Let C_it denote source commitments in millions of constant 2023 US dollars and P_it population. Per-person financing is F_it = 10^6 C_it / P_it. The principal dependent variable is H_it = ln(1 + F_it). The addition of one permits observed zeros without deleting them. Its interpretation depends on the dollar-per-person unit, especially at low financing values where the transformation differs from percentage growth.

The baseline equation is:
H_it = α_i + λ_t + β(T_i,t−1 / 10) + γ ln(Y_i,t−1) + δ D_i,t−1 + ε_it.
Here T is openness, Y is real GDP per person, D is FDI as a percentage of GDP, α_i are country effects, and λ_t are year effects. The coefficient β compares within-country changes in lagged openness after common annual shocks and the observed controls are removed.

ISO country identifiers link the sources to a complete annual grid. Raw zeros and negative net FDI observations are retained. Country lags are created after sorting by year. The full panel contains 375 rows, including fifteen 1999 observations used only for control lags. The financing regression contains 360 rows. No interpolation, synthetic values, or manual alteration of reported finance is used.

Pooled estimation excludes country effects; the random effects model includes year indicators; the principal model includes both country and year effects. A correlated random effects comparison adds country means of the three regressors. Ordinary least squares with explicit indicators was checked against the within estimator: the main openness point estimate agrees numerically.

The model estimates an association. Country effects account for stable differences. Changing donor priorities, reforms, interest rates, and project pipelines can still influence the estimates. Year effects account for common shocks; individual country trends need separate controls. Using last year’s openness sets a time order without supplying an independent policy experiment. Reverse causality and omitted factors are still possible.

# 3.3 Diagnostic Tests and Final Model Selection

The joint poolability F-test rejects common intercepts (p < 0.0001). The clustered Mundlak country-mean test also rejects the random effects orthogonality restriction (p = 0.0268). These results, together with the goal of within-country comparison, favour the country/year fixed effects specification. The conventional F-test assumes homoskedastic errors and is supplementary rather than definitive.

Breusch–Pagan does not reject heteroskedasticity, and the first-difference residual test does not reject its no-serial-correlation restriction. Neither non-rejection proves independent, homoskedastic errors. The approximate Pesaran CD test flags cross-country dependence; demeaning and short samples can affect its reference distribution.

Clustered inference uses the finite-group covariance correction and a t reference with G − 1 degrees of freedom (14 in the main sample). Inference compares country clustering, Driscoll–Kraay covariance (Bartlett kernel, bandwidth three), and a restricted wild country-cluster bootstrap with 9,999 Rademacher draws (seed 311). The bootstrap addresses few-cluster inference, not dependence between countries. Driscoll–Kraay also has finite-sample limits with only 24 years (Cameron et al., 2008; Driscoll & Kraay, 1998).

Within-transformed VIFs range from 1.008 to 1.019, indicating little collinearity. Individual ADF tests reject a unit root at 5% for 11/15 finance-level series, 2/15 trade series, and 15/15 finance-change series. Joint panel stationarity remains uncertain given the short individual series. First-difference and country-trend models are consequently reported as substantive sensitivity checks.

Table 2. Diagnostic and inference checks

| Diagnostic | Statistic | p-value |

| --- | --- | --- |

| Poolability F (country and year effects jointly) | 9.6870 | <0.0001 |

| Mundlak country-mean joint Wald (clustered) | 9.1946 | 0.0268 |

| Breusch-Pagan heteroskedasticity (exploratory) | 1.0484 | 0.7895 |

| FD residual AR(1), H0 coefficient = -0.5 | 1.4940 | 0.1574 |

| Pesaran CD residual test (approximate) | -2.6889 | 0.0072 |

| Wild country-cluster bootstrap trade H0=0 | 2.8787 | 0.0734 |

# 4. Results and Discussion: Principal Model

In the main fixed effects model, the openness coefficient is 0.1080. Its country-clustered standard error is 0.0375, the p-value is 0.0121, and the 95% confidence interval runs from 0.0275 to 0.1885. This supports a positive association under the baseline assumptions. The bootstrap and alternative models reveal sensitivity that qualifies this finding.

A ten percentage point increase in preceding-year openness is associated with a 0.108 increase in ln(1 + financing per person). Under the fitted transformation, one plus financing is multiplied by exp(0.108), approximately 1.114. The 11.4% applies to one plus finance. The percentage change in finance itself depends on its starting value. If an illustrative starting amount is one dollar per person, the fitted change is about 0.228 dollars, holding other regressors and effects fixed.

The income coefficient is negative and the FDI coefficient is positive. One possible explanation is that public development finance responds to recipient needs. FDI may also reflect broader financial connections or economic conditions missing from the model. Distinguishing these explanations requires additional evidence. The FDI measure also covers sectors beyond renewable energy.

The wild-cluster bootstrap gives p = 0.0734, between the 5% and 10% thresholds. Driscoll–Kraay inference gives a smaller standard error and p < 0.0001. These methods make different assumptions, so the difference matters. With only fifteen country clusters, the evidence is less certain than the baseline p-value alone suggests.

The two-way within R² is 0.1074: the observed regressors explain about 10.7% of the financing variation remaining after country and year effects are removed. Financing also depends on donor priorities, project pipelines, and policy conditions that are outside the model.

Table 3. Principal fixed effects financing model

| Regressor | Coefficient | Cluster SE | Cluster p | DK SE | DK p |

| --- | --- | --- | --- | --- | --- |

| Lagged openness / 10 | 0.1080 | 0.0375 | 0.0121 | 0.0216 | <0.0001 |

| Lagged ln income/person | -0.8754 | 0.3810 | 0.0375 | 0.1900 | <0.0001 |

| Lagged FDI / GDP | 0.0671 | 0.0224 | 0.0097 | 0.0226 | 0.0033 |

# 4.1 Descriptive Evidence

Average clean energy commitments are 2.66 constant dollars per person, while the median is only 0.60. The maximum is 47.82 dollars per person. Average total commitments are about 284 million constant dollars per country-year. The gap between means and medians reflects lumpy finance and project timing, supporting the use of a transformation while also cautioning against a smooth annual interpretation.

Lagged openness averages 68.7%, ranging from about 21.0% to 220.4%. This spread reflects economic size and integration across the purposive sample. There are thirteen reported zero-finance observations. A zero refers to the recorded commitments in this source. Domestic renewable investment and other clean energy activity can still take place.

Figure 1 illustrates five financing trajectories; all fifteen countries are retained in the regression and source files. The variation is much less smooth than renewable generation. Commitments can be booked before construction and disbursement, so a finance peak need not coincide with an electricity-output increase.

Table 4. Descriptive statistics, 360 country-year observations

| Variable | Mean | SD | Minimum | Maximum |

| --- | --- | --- | --- | --- |

| Commitments (2023 US$/person) | 2.6570 | 5.2822 | 0.0000 | 47.8158 |

| Commitments (2023 US$ million) | 284.2695 | 462.4547 | 0.0000 | 3309.4800 |

| Lagged openness (%) | 68.7333 | 41.7431 | 20.9822 | 220.4068 |

| Real GDP/person (2015 US$) | 5334.8028 | 3023.0321 | 756.7041 | 14932.8851 |

| FDI inflows (% GDP) | 2.6408 | 1.6328 | -2.7574 | 9.6810 |

# 4.2 Visual Evidence

Figure 1 describes the timing and scale of recorded commitments. Identifying the trade mechanism requires further evidence. Figure 2 contrasts baseline and more restrictive specifications. Intervals are conventional country-clustered 95% intervals. The first-difference model changes both outcome and regressor variation, so its coefficient should be read as a sensitivity comparison with a different estimand.

![Figure 1. International public clean energy financing commitments](finance_trends.png)

![Figure 2. Openness association under alternative specifications](coefficient_sensitivity.png)

# 4.3 Robustness Results

The pooled and random effects coefficients are negative and imprecise, whereas baseline fixed effects are positive. The model diagnostics help explain why a between-country comparison is not interchangeable with the within-country relationship. Excluding China, restricting the end year to 2019, using current controls, and applying an inverse hyperbolic sine transformation preserve the positive conventional result.

Important restrictions weaken it. Starting in 2010 gives β = 0.0356 and p = 0.3321; country trends give β = 0.0518 and p = 0.2183; first differences give β = −0.0334 and p = 0.7431. First differences use 345 observations. Leave-one-country-out estimates remain positive, but excluding Malaysia gives p = 0.1785. Full coefficients and intervals are included in the research package.

These checks use variations of the same dataset and therefore share its underlying limitations. They show that the answer depends on which changes over time the model uses. The positive baseline estimate merits further investigation, particularly because several alternative specifications weaken it.

Table 5. Openness coefficients across all financing specifications

| Specification | Openness β | SE | p-value |

| --- | --- | --- | --- |

| Pooled (no effects) | -0.0250 | 0.0264 | 0.3592 |

| Random effects + years | -0.0231 | 0.0171 | 0.1981 |

| Two-way FE (cluster) | 0.1080 | 0.0375 | 0.0121 |

| Two-way FE (DK) | 0.1080 | 0.0216 | <0.0001 |

| FE excluding China | 0.1123 | 0.0371 | 0.0096 |

| FE through 2019 | 0.1370 | 0.0428 | 0.0064 |

| FE inverse hyperbolic sine | 0.1372 | 0.0474 | 0.0117 |

| FE 2010 onward | 0.0356 | 0.0355 | 0.3321 |

| FE log total finance | 0.1634 | 0.0759 | 0.0493 |

| FE current controls | 0.1131 | 0.0364 | 0.0078 |

| FE first differences | -0.0334 | 0.0999 | 0.7431 |

| FE country trends | 0.0518 | 0.0402 | 0.2183 |

# 4.4 Economic Interpretation and Limitations

The baseline result is compatible with technology-access and financing channels: international integration may help recipients obtain equipment and connect projects with public lenders. Yet this interpretation is only one possibility. Donors can allocate funding to strategic trade partners, policy reforms can affect both openness and finance, and project commitments can themselves influence future imports. These channels remain possible even with lagged openness.

The financing measure, sample, and model each limit what can be concluded. International public finance leaves out much of total clean energy spending. Payment dates and plant completion require separate records. The fifteen countries were deliberately selected, and one common coefficient cannot describe every emerging economy’s response. Technology-specific effects remain outside the model.

The country-trend and first-difference results are especially relevant because openness is persistent and most individual trade series do not reject an ADF unit-root null. Non-stationarity requires attention beyond the inclusion of fixed effects. The baseline significance weakens in these alternative specifications. A long-run equilibrium interpretation would require a valid cointegration analysis.

Supplementary analysis uses solar and wind generation data from Our World in Data. With the same countries, controls, and period, the deployment-growth openness coefficient is 0.0059 with a conventional country-clustered p-value above 0.8. The difference in outcome and timing allows financing and deployment to follow distinct patterns. Its complete transformations, estimates, and diagnostics are supplied separately. Generation is treated as a separate outcome.

Several checks weaken confidence in the positive baseline association. A causal assessment of trade liberalisation, including whether particular policies work, requires evidence beyond this study.

# 5. Conclusion and Policy Implications

The starting question was straightforward: does trade openness encourage clean energy investment in emerging markets? There are good reasons to expect a connection. Renewable projects often depend on imported equipment, technical knowledge, and finance from abroad. Easier trade may help developers obtain these inputs. Trade also includes fossil fuels and energy-intensive goods, which can direct investment towards conventional energy. The results need to be read with that distinction in mind.

The report uses fifteen economies over 2000–2023, giving 360 country-year observations. Its financing measure comes from the UN SDG database, drawing on OECD and IRENA sources. It records international public commitments for clean energy in constant 2023 dollars. Dividing by population makes country sizes more comparable. World Bank data provide openness, income, FDI, and population. The renewable technology total is used once to avoid double counting its components. Reported zeros are kept, missing values are not filled in, and all observations needed for the main model are available.

The baseline model finds a positive association between the previous year's trade openness and financing per person. A ten percentage point increase in openness is associated with a 0.108 increase in the logarithm of one plus finance per person. Country-clustered inference rejects a zero coefficient. The model tests also support accounting for country differences: pooled and random effects estimates have different signs from the fixed effects result. Cross-country comparisons and within-country changes use different sources of variation, which helps explain the differing estimates.

That positive estimate is only part of the answer. The wild-cluster bootstrap does not reject zero at five percent. The relationship is also statistically uncertain when country trends are added, the sample begins in 2010, or first differences are used. Dropping Malaysia weakens significance too. These results make it difficult to claim that the baseline association holds across reasonable alternative specifications. The separate generation analysis provides no clear evidence of a corresponding rise in solar and wind output. Financing commitments may precede construction, and some may not translate into completed projects within the period examined.

For policy, the useful question is which part of trade could help a renewable project. Tariffs on equipment, customs delays, technical standards, and access to procurement are more specific than the overall trade-to-GDP ratio. Governments could examine these costs using project records before choosing an intervention. Public lenders should also report commitments, disbursements, construction progress, and operating output separately. That would make it easier to see whether announced finance becomes a working asset. Reliable grid connections and credible electricity purchase contracts are additional mechanisms worth evaluating. Assessing their effects requires a separate policy analysis.

The baseline model associates greater openness with higher international public clean energy finance. Sensitivity across specifications and the observational design limit the strength of that conclusion. It says little directly about total domestic and private investment. A stronger study would use broader project expenditure data, distinguish financing sources and technologies, and examine clearly identified tariff reforms or external supply changes. The evidence available here supports further investigation of the trade–finance link. Its implications for total clean energy investment remain open.

# Appendix: Individual-Series Stationarity Diagnostics

The ADF null is a unit root. A constant and linear trend are included for trade and transformed financing levels; finance changes include a constant. AIC selects up to two lags. Trade has 1999–2023 observations, finance levels 2000–2023, and finance changes 2001–2023 before lag adjustment. These are short individual-series diagnostics, without multiple-testing adjustment or a cross-sectionally robust panel reference distribution.

All countries contribute 24 observations to the principal regression. The complete ADF statistics, selected lags, and effective counts are in outputs/adf_exploratory.csv. The main-model sample audit, all tested coefficients, and raw source responses are included in the companion reproducibility package.

Table A1. All individual ADF p-values

| Country | Trade ADF p | Finance ADF p | Finance-change ADF p |

| --- | --- | --- | --- |

| BRA | 0.7090 | <0.0001 | <0.0001 |

| CHN | 0.4062 | 0.6334 | <0.0001 |

| IND | 0.7882 | 0.0082 | <0.0001 |

| IDN | 0.0006 | 0.0010 | <0.0001 |

| MEX | 0.0830 | 0.9960 | <0.0001 |

| TUR | 0.9473 | 0.1317 | <0.0001 |

| ZAF | 0.0677 | 0.0045 | <0.0001 |

| THA | 0.0896 | 0.0015 | 0.0004 |

| MYS | 0.7488 | <0.0001 | <0.0001 |

| PHL | 0.8441 | 0.0165 | <0.0001 |

| VNM | 0.3130 | 0.0002 | <0.0001 |

| EGY | 0.3130 | 0.0003 | <0.0001 |

| MAR | 0.0946 | 0.0092 | 0.0002 |

| COL | 0.0184 | 0.0063 | <0.0001 |

| PER | 0.6237 | 0.2956 | 0.0003 |

# References

Antweiler, W., Copeland, B. R., & Taylor, M. S. (2001). Is free trade good for the environment? American Economic Review, 91(4), 877–908. https://doi.org/10.1257/aer.91.4.877

Appiah-Otoo, I., Ampah, J. D., & Chen, X. (2025). Governance, financial openness, and renewable energy investment in Africa. Journal of Policy Modeling, 47(5), 958–976. https://doi.org/10.1016/j.jpolmod.2025.05.003

Cameron, A. C., Gelbach, J. B., & Miller, D. L. (2008). Bootstrap-based improvements for inference with clustered errors. Review of Economics and Statistics, 90(3), 414–427. https://doi.org/10.1162/rest.90.3.414

Copeland, B. R., & Taylor, M. S. (2004). Trade, growth, and the environment. Journal of Economic Literature, 42(1), 7–71. https://doi.org/10.1257/002205104773558047

Driscoll, J. C., & Kraay, A. C. (1998). Consistent covariance matrix estimation with spatially dependent panel data. Review of Economics and Statistics, 80(4), 549–560. https://doi.org/10.1162/003465398557825

Ebaidalla, E. M. (2024). The impact of taxation, technological innovation and trade openness on renewable energy investment: Evidence from the top renewable energy producing countries. Energy, 306, Article 132539. https://doi.org/10.1016/j.energy.2024.132539

Eyraud, L., Clements, B., & Wane, A. (2013). Green investment: Trends and determinants. Energy Policy, 60, 852–865. https://doi.org/10.1016/j.enpol.2013.04.039

Eyraud, L., Zhang, C., Wane, A., & Clements, B. (2011). Who’s going green and why? Trends and determinants of green investment (IMF Working Paper No. 11/296). International Monetary Fund. https://doi.org/10.5089/9781463927301.001

Our World in Data. (n.d.). Energy data [Data set; legacy release]. Retrieved October 12, 2026, from https://github.com/owid/energy-data

Polzin, F., Migendt, M., Täube, F. A., & von Flotow, P. (2015). Public policy influence on renewable energy investments—A panel data study across OECD countries. Energy Policy, 80, 98–111. https://doi.org/10.1016/j.enpol.2015.01.026

United Nations Statistics Division. (n.d.). Global SDG indicators database: Series EG_IFF_RANDN [Data set]. Retrieved October 12, 2026, from https://unstats.un.org/SDGAPI/v1/sdg/Series/Data?seriesCode=EG_IFF_RANDN

United Nations Statistics Division. (2026). SDG indicator 7.a.1: Metadata. https://unstats.un.org/sdgs/metadata/files/Metadata-07-0a-01.pdf

World Bank. (n.d.). World Development Indicators [Data set]. Retrieved October 12, 2026, from https://api.worldbank.org/v2/