# Does Trade Openness Encourage Clean Energy Investment? Evidence from Emerging Markets

ECON F311 — International Economics

BITS Pilani, Pilani Campus

International public clean energy financing commitments, 2000–2023

Group 17

Ritik Yadav — 2024B3A30940

Sriansh Rajan — 2024B3A80901P

Nidhish Kumar Tyagi — 2024B3A80952P

Heet Jain — 2024B3A80929P

Jaivardhan Singh — 2024B3A40859P

12 October 2026

# Abstract

Trade openness may encourage clean energy investment by reducing equipment costs and improving access to technology and finance, but it can also expand conventional energy demand. This study investigates the relationship using a balanced panel of fifteen selected emerging market economies over 2000–2023. The investment-related outcome is international public financing commitments for clean energy, obtained from the United Nations Sustainable Development Goal indicator 7.a.1 and expressed in constant 2023 United States dollars per person. It excludes total domestic and private investment and does not measure disbursements. World Bank data provide trade openness, real income per person, foreign direct investment, and population. The analysis compares pooled, random effects, and country and year fixed effects models. Model-restriction tests favour fixed effects; additional diagnostics examine heteroskedasticity, serial correlation, cross-country dependence, collinearity, and individual-series stationarity. In the baseline specification, a ten percentage point increase in lagged trade openness is associated with a 0.108 increase in the logarithm of one plus financing per person. The country-clustered p-value is 0.012, while a restricted wild-cluster bootstrap gives 0.073. Estimates remain positive when China is excluded and the pre-pandemic period is used. However, the relationship is not statistically significant in the recent-period, country-trend, or first-difference specifications. Supplementary solar and wind generation estimates do not establish a corresponding deployment-growth relationship. The findings are therefore suggestive rather than causal or uniformly robust. Policy should distinguish targeted renewable equipment trade from aggregate openness, and financing commitments from realised investment. Stronger project-level data and a credible identification strategy are needed before asserting that trade liberalisation raises total clean energy investment.

Keywords: trade openness; clean energy finance; emerging markets; panel data; renewable investment

# 1. Introduction

Clean energy investment depends on more than domestic demand for electricity. Solar modules, turbine components, specialised machinery, and engineering services often cross borders before a project begins operating. International trade can make equipment available at lower cost, improve technology choices, and connect domestic developers with external suppliers. These channels motivate a positive relationship between openness and investment.

The relationship need not be uniformly positive. Trade can expand energy-intensive manufacturing or facilitate fossil fuel imports. Developers may face expensive credit, uncertain electricity contracts, or grid constraints even when imported technology is accessible. International public finance may respond to development needs and donor priorities rather than commercial openness. The empirical question therefore requires a precisely defined investment measure and a model that distinguishes persistent country differences from changes over time.

Antweiler et al. (2001) separate trade's environmental effects into scale, composition, and technique channels. Their evidence concerns pollution, not renewable finance, so its conclusion cannot be transferred directly. Copeland and Taylor (2004) situate trade and growth in the environmental literature. Applied here, these frameworks suggest that aggregate openness combines competing mechanisms and need not capture targeted liberalisation of renewable equipment.

The study has three objectives: to assemble a reproducible country-year dataset of clean energy financing; to estimate its association with preceding-year trade openness while comparing panel-model assumptions; and to assess whether the result survives alternative inference and specifications. Its contribution is a selected-country comparison that documents the financing measure, evaluates model assumptions, and reports specification sensitivity.

The outcome is international public financing commitments for clean energy, rather than all investment expenditure. This distinction is central: commitments do not necessarily become disbursements or completed assets, and domestic or purely private investment is largely outside coverage. The paper answers a narrower operational version of the title's question and keeps these limitations explicit throughout.

# 2. Literature Review

The environmental trade literature explains why the sign of the relationship is ambiguous. Antweiler et al. (2001) investigate pollution concentrations using scale, composition, and technique effects; their published abstract reports a net pollution-reducing result in their setting. This provides a mechanism framework rather than evidence about the financing measure used here. Copeland and Taylor (2004) offer a broader review of trade, growth, and environmental outcomes. Neither source warrants assuming that aggregate trade must raise renewable investment.

Eyraud et al. (2013) study green investment and its determinants. The related IMF working paper summarises historical evidence from advanced and emerging economies and identifies growth, financing conditions, fuel prices, and policy instruments as relevant factors (Eyraud et al., 2011). This motivates income and financial-context controls. The working paper and journal article belong to the same research line and are treated as related evidence rather than independent replications.

Polzin et al. (2015) examine public policy and renewable investment in an OECD panel. That setting differs from this emerging-market recipient-country analysis. It highlights the relevance of policy conditions, which country fixed effects can capture only when they are stable. Changing procurement rules, support schemes, and financing conditions remain possible omitted variables in the present design.

Ebaidalla (2024) directly connects taxation, technological innovation, trade openness, and renewable investment in its research question. Appiah-Otoo et al. (2025) examine governance, financial openness, and renewable investment in Africa. Financial openness is distinct from the goods-and-services trade ratio used here. These studies motivate attention to taxation, technological change, governance, and financing conditions. The comparison here concerns their research scope; detailed findings from unreviewed full texts are not attributed to them.

This study examines whether a within-country relationship appears in a public clean energy financing panel and whether it survives controls for trends, alternative periods, and inference with few countries. The outcome, selected sample, and reproducibility package distinguish this exercise from the cited studies. The contribution lies in the selected financing measure and sensitivity analysis, rather than a claim that the topic has not been studied.

# 3. Data and Methodology: Sources and Sample

The sample contains Brazil, China, India, Indonesia, Mexico, Türkiye, South Africa, Thailand, Malaysia, the Philippines, Viet Nam, Egypt, Morocco, Colombia, and Peru. It is a purposive selection across Latin America, Asia, and Africa, rather than an exhaustive emerging-market index list. Viet Nam is included for regional coverage. The results should not be generalised to every emerging or developing economy.

The analytical period is 2000–2023. World Bank data for 1999 provide the first preceding-year controls. The UN series also contains 2024 financing observations, but the main panel uses the period fixed during collection of the controls; those later observations are preserved in the raw responses and are not used. All 360 candidate observations are available for the main regression.

The dependent variable uses SDG indicator 7.a.1, series EG_IFF_RANDN. OECD and IRENA compile international public support for clean energy research and renewable energy production, including hybrid systems. The retrieved series records recipient-country commitments in millions of constant 2023 US dollars. Source footnotes identify donor-country deflators and exchange-rate conventions. No additional CPI conversion is applied.

The technology dimension ALL is selected once per country and year, with reporting type G. It is not added to its technology components, which would double count the flows. Each raw country response has 200 records: 25 years and eight technology categories. The main sample contains thirteen explicitly reported zero aggregate commitments. These zeros remain in the model; missing values are not converted into zeros.

The outcome covers public international finance, not total domestic and private investment, and measures commitments rather than actual expenditure. The current data source labels observations Nature = E; the source status is retained without relabelling them as audited project transactions. UN methodology and source footnotes are archived. Duplicate keys, pagination completeness, units, base period, technology filters, and sample inclusion are checked in the scripts.

# 3.1 Variables, Sources, and Rationale

Trade openness is a realised trade ratio rather than statutory tariff policy. It can change because of commodity prices, exchange rates, or GDP changes. Values above 100% are legitimate because gross imports and exports are compared with domestic value added. Trade is divided by ten in estimation; its coefficient refers to a ten percentage point change.

Real income per person is measured in constant 2015 US dollars and enters in logarithms. Development can influence renewable demand, financing capacity, and eligibility for concessional support. FDI is a broad financing-context measure, not a measure of renewable-sector investment. Both controls are lagged by one year. Lagging reduces contemporaneous overlap but does not establish exogeneity.

Population converts international commitments into comparable per-person amounts. Dividing by GDP would combine the outcome with another denominator and would require compatible real-price definitions. The principal model therefore uses per-person commitments. A total-finance specification with a population control checks whether this scale choice drives the result.

Table 1. Variables and data sources

| Variable | Definition / units | Source and rationale |

| --- | --- | --- |

| Clean energy finance | ln(1 + commitments in 2023 US$/person) | UN SDG 7.a.1; principal outcome |

| Trade openness | Exports plus imports / GDP × 100; lagged | WDI NE.TRD.GNFS.ZS; exposure |

| Real income/person | Natural logarithm; lagged | WDI NY.GDP.PCAP.KD; development |

| FDI inflows | Net inflows / GDP × 100; lagged | WDI BX.KLT.DINV.WD.GD.ZS; finance context |

| Population | Persons | WDI SP.POP.TOTL; scale adjustment |

| Country/year effects | Country intercepts; annual indicators | Stable heterogeneity/common shocks |

# 3.2 Data Transformations and Model Equation

Let C_it denote source commitments in millions of constant 2023 US dollars and P_it population. Per-person financing is F_it = 10^6 C_it / P_it. The principal dependent variable is H_it = ln(1 + F_it). The addition of one permits observed zeros without deleting them. Its interpretation depends on the stated dollar-per-person unit and is not an exact percentage change in financing at low values.

The baseline equation is:
H_it = α_i + λ_t + β(T_i,t−1 / 10) + γ ln(Y_i,t−1) + δ D_i,t−1 + ε_it.
Here T is openness, Y is real GDP per person, D is FDI as a percentage of GDP, α_i are country effects, and λ_t are year effects. The coefficient β compares within-country changes in lagged openness after common annual shocks and the observed controls are removed.

ISO country identifiers link the sources to a complete annual grid. Raw zeros and negative net FDI observations are retained. Country lags are created after sorting by year. The full panel contains 375 rows, including fifteen 1999 observations used only for control lags. The financing regression contains 360 rows. No interpolation, synthetic values, or manual alteration of reported finance is used.

Pooled estimation excludes country effects; the random effects model includes year indicators; the principal model includes both country and year effects. A correlated random effects comparison adds country means of the three regressors. Ordinary least squares with explicit indicators was checked against the within estimator: the main openness point estimate agrees numerically.

This is an associational design. Country effects remove stable differences but not changing donor priorities, policy reforms, interest rates, or project pipelines. Annual indicators capture shared shocks but not country-specific trends. A preceding-year exposure is a timing choice, not an instrument. Reverse causality and omitted-variable bias remain possible.

# 3.3 Diagnostic Tests and Final Model Selection

The joint poolability F-test rejects common intercepts (p < 0.0001). The clustered Mundlak country-mean test also rejects the random effects orthogonality restriction (p = 0.0268). These results, together with the goal of within-country comparison, favour the country/year fixed effects specification. The conventional F-test assumes homoskedastic errors and is supplementary rather than definitive.

Breusch–Pagan does not reject heteroskedasticity, and the first-difference residual test does not reject its no-serial-correlation restriction. Neither non-rejection proves independent, homoskedastic errors. The approximate Pesaran CD test flags cross-country dependence; demeaning and short samples can affect its reference distribution.

Clustered inference uses the finite-group covariance correction and a t reference with G − 1 degrees of freedom (14 in the main sample). Inference compares country clustering, Driscoll–Kraay covariance (Bartlett kernel, bandwidth three), and a restricted wild country-cluster bootstrap with 9,999 Rademacher draws (seed 311). The bootstrap addresses few-cluster inference, not dependence between countries. Driscoll–Kraay also has finite-sample limits with only 24 years (Cameron et al., 2008; Driscoll & Kraay, 1998).

Within-transformed VIFs range from 1.008 to 1.019, indicating little collinearity. Individual ADF tests reject a unit root at 5% for 11/15 finance-level series, 2/15 trade series, and 15/15 finance-change series. These short-series tests do not establish joint panel stationarity. First-difference and country-trend models are consequently reported as substantive sensitivity checks.

Table 2. Diagnostic and inference checks

| Diagnostic | Statistic | p-value |

| --- | --- | --- |

| Poolability F (country and year effects jointly) | 9.6870 | <0.0001 |

| Mundlak country-mean joint Wald (clustered) | 9.1946 | 0.0268 |

| Breusch-Pagan heteroskedasticity (exploratory) | 1.0484 | 0.7895 |

| FD residual AR(1), H0 coefficient = -0.5 | 1.4940 | 0.1574 |

| Pesaran CD residual test (approximate) | -2.6889 | 0.0072 |

| Wild country-cluster bootstrap trade H0=0 | 2.8787 | 0.0734 |

# 4. Results and Discussion: Principal Model

The country/year fixed effects model estimates a positive openness coefficient of 0.1080, with country-clustered standard error 0.0375 and p = 0.0121. The corresponding 95% interval is 0.0275 to 0.1885. These are conventional approximate panel inference results. They must be assessed alongside the bootstrap and alternative specifications rather than treated as the final proof of the hypothesis.

A ten percentage point increase in preceding-year openness is associated with a 0.108 increase in ln(1 + financing per person). Under the fitted transformation, one plus financing is multiplied by exp(0.108), approximately 1.114. This is an 11.4% change in one plus finance, not necessarily an 11.4% change in finance itself. If an illustrative starting amount is one dollar per person, the fitted change is about 0.228 dollars, holding other regressors and effects fixed.

Income has a negative coefficient, while FDI has a positive coefficient. The income pattern is consistent with the possibility that public development finance responds to recipient needs, but the regression does not identify that mechanism. FDI may capture broader external financial relationships or omitted economic conditions. Their coefficients should not be interpreted as direct effects of growth or renewable-sector FDI.

The restricted wild-cluster bootstrap yields p = 0.0734. It does not reject at 5%, although it would at 10%. Driscoll–Kraay inference gives a smaller standard error and p < 0.0001. Because the inference methods rely on different assumptions, this disagreement is material. The result is positive in the baseline specification but less secure when uncertainty with only fifteen clusters is emphasised.

The two-way within R² is 0.1074: the observed regressors explain about 10.7% of the financing variation remaining after country and year effects are removed. Financing also depends on donor priorities, project pipelines, and policy conditions that are outside the model.

Table 3. Principal fixed effects financing model

| Regressor | Coefficient | Cluster SE | Cluster p | DK SE | DK p |

| --- | --- | --- | --- | --- | --- |

| Lagged openness / 10 | 0.1080 | 0.0375 | 0.0121 | 0.0216 | <0.0001 |

| Lagged ln income/person | -0.8754 | 0.3810 | 0.0375 | 0.1900 | <0.0001 |

| Lagged FDI / GDP | 0.0671 | 0.0224 | 0.0097 | 0.0226 | 0.0033 |

# 4.1 Descriptive Evidence

Average clean energy commitments are 2.66 constant dollars per person, while the median is only 0.60. The maximum is 47.82 dollars per person. Average total commitments are about 284 million constant dollars per country-year. The gap between means and medians reflects lumpy finance and project timing, supporting the use of a transformation while also cautioning against a smooth annual interpretation.

Lagged openness averages 68.7%, ranging from about 21.0% to 220.4%. This spread reflects economic size and integration across the purposive sample. There are thirteen reported zero-finance observations. A zero means zero recorded commitments in this source, not zero domestic renewable investment or zero clean energy activity.

Figure 1 illustrates five financing trajectories; all fifteen countries are retained in the regression and source files. The variation is much less smooth than renewable generation. Commitments can be booked before construction and disbursement, so a finance peak need not coincide with an electricity-output increase.

Table 4. Descriptive statistics, 360 country-year observations

| Variable | Mean | SD | Minimum | Maximum |

| --- | --- | --- | --- | --- |

| Commitments (2023 US$/person) | 2.6570 | 5.2822 | 0.0000 | 47.8158 |

| Commitments (2023 US$ million) | 284.2695 | 462.4547 | 0.0000 | 3309.4800 |

| Lagged openness (%) | 68.7333 | 41.7431 | 20.9822 | 220.4068 |

| Real GDP/person (2015 US$) | 5334.8028 | 3023.0321 | 756.7041 | 14932.8851 |

| FDI inflows (% GDP) | 2.6408 | 1.6328 | -2.7574 | 9.6810 |

# 4.2 Visual Evidence

Figure 1 describes recorded commitments; it does not establish a trade mechanism. Figure 2 contrasts baseline and more restrictive specifications. Intervals are conventional country-clustered 95% intervals. The first-difference model changes both outcome and regressor variation, so its coefficient is a sensitivity comparison rather than an identical estimand.

![Figure 1. International public clean energy financing commitments](finance_trends.png)

![Figure 2. Openness association under alternative specifications](coefficient_sensitivity.png)

# 4.3 Robustness Results

The pooled and random effects coefficients are negative and imprecise, whereas baseline fixed effects are positive. The model diagnostics help explain why a between-country comparison is not interchangeable with the within-country relationship. Excluding China, restricting the end year to 2019, using current controls, and applying an inverse hyperbolic sine transformation preserve the positive conventional result.

Important restrictions weaken it. Starting in 2010 gives β = 0.0356 and p = 0.3321; country trends give β = 0.0518 and p = 0.2183; first differences give β = −0.0334 and p = 0.7431. First differences use 345 observations. Leave-one-country-out estimates remain positive, but excluding Malaysia gives p = 0.1785. Full coefficients and intervals are included in the research package.

These checks are not independent replications. They reveal dependence on the time variation and assumptions used. The paper therefore describes the baseline relationship as suggestive, rather than selecting the smallest p-value or claiming uniformly robust evidence.

Table 5. Openness coefficients across all financing specifications

| Specification | Openness β | SE | p-value |

| --- | --- | --- | --- |

| Pooled (no effects) | -0.0250 | 0.0264 | 0.3592 |

| Random effects + years | -0.0231 | 0.0171 | 0.1981 |

| Two-way FE (cluster) | 0.1080 | 0.0375 | 0.0121 |

| Two-way FE (DK) | 0.1080 | 0.0216 | <0.0001 |

| FE excluding China | 0.1123 | 0.0371 | 0.0096 |

| FE through 2019 | 0.1370 | 0.0428 | 0.0064 |

| FE inverse hyperbolic sine | 0.1372 | 0.0474 | 0.0117 |

| FE 2010 onward | 0.0356 | 0.0355 | 0.3321 |

| FE log total finance | 0.1634 | 0.0759 | 0.0493 |

| FE current controls | 0.1131 | 0.0364 | 0.0078 |

| FE first differences | -0.0334 | 0.0999 | 0.7431 |

| FE country trends | 0.0518 | 0.0402 | 0.2183 |

# 4.4 Economic Interpretation and Limitations

The baseline result is compatible with technology-access and financing channels: international integration may help recipients obtain equipment and connect projects with public lenders. Yet this interpretation is only one possibility. Donors can allocate funding to strategic trade partners, policy reforms can affect both openness and finance, and project commitments can themselves influence future imports. Lagged openness does not exclude these channels.

Three boundaries constrain the answer. First, the recorded outcome is international public finance, not total clean energy capital expenditure. Second, commitments are not disbursements or completed plants. Third, the purposive fifteen-country sample and common slope cannot represent every emerging economy or its specific response. The analysis does not estimate technology-specific financing effects.

The country-trend and first-difference results are especially relevant because openness is persistent and most individual trade series do not reject an ADF unit-root null. Fixed effects alone do not resolve non-stationarity. These alternative specifications do not reproduce the baseline significance, so the paper avoids presenting the levels regression as a proven long-run equilibrium or using a cointegration label without a valid test.

Supplementary analysis uses solar and wind generation data from Our World in Data. With the same countries, controls, and period, the deployment-growth openness coefficient is 0.0059 with a conventional country-clustered p-value above 0.8. It neither establishes an immediate deployment response nor refutes the financing result, because the outcome and timing differ. Its complete transformations, estimates, and diagnostics are supplied separately. Generation is never relabelled as investment.

The defensible interpretation is conditional: the baseline public-finance association is positive, while stronger specification and few-cluster checks reduce confidence. Claims that trade-policy liberalisation causes more total clean energy investment, or that openness is ineffective, would both exceed the completed evidence.

# 5. Conclusion and Policy Implications

This study examined whether trade openness encourages clean energy investment in selected emerging markets. The question matters because international trade can connect developers with equipment, technology, and sources of finance. Yet openness can also expand conventional energy use and reflect changes in export prices or national income. A positive investment response is therefore plausible but not guaranteed. The analysis distinguishes public financing commitments from completed investment and renewable electricity production.

The completed dataset combines fifteen economies over 2000–2023, giving 360 country-year observations. Its outcome is international public financing commitments for clean energy, compiled through the United Nations SDG database from OECD and IRENA sources. Commitments are expressed in constant 2023 dollars and divided by population. Trade openness, real income per person, and FDI are obtained from the World Bank. The source aggregate for all renewable technologies is used once, avoiding double counting of technology components. Reported zero commitments are retained, missing observations are not imputed, and every main-model observation meets the data requirements.

The baseline country and year fixed effects model finds a positive relationship between preceding-year openness and transformed financing per person. A ten percentage point rise in the trade ratio is associated with an increase of 0.108 in the logarithm of one plus finance per person. Conventional country-clustered inference rejects a zero coefficient. Model-restriction tests also support controlling for country heterogeneity rather than relying on the pooled or random effects estimates, which show different signs. This contrast illustrates why a simple cross-country comparison can obscure the within-country relationship.

However, the evidence does not justify an unqualified affirmative answer. The restricted wild-cluster bootstrap does not reject at five percent, and the estimate is statistically uncertain when country trends are added, the period begins in 2010, or the model uses first differences. Leaving Malaysia out also weakens conventional significance. These checks show that the positive baseline result depends partly on the variation and assumptions used. Supplementary generation results further indicate that financing patterns cannot simply be interpreted as an immediate increase in renewable electricity production.

The principal policy implication is to examine the mechanisms behind openness rather than adopt a broad trade target as a renewable investment instrument. Governments can evaluate tariffs and customs procedures for renewable equipment, technical standards, and procurement access with project-level cost evidence. Financing institutions can improve transparency by separating commitments, disbursements, construction milestones, and operating output. Reliable grid connection and credible purchase contracts may help projects convert financing into assets, but this study does not estimate the effect of those policies. Their recommendation follows from plausible mechanisms and the data limitations, not a measured causal return.

The final conclusion is conditional: greater openness is associated with higher international public clean energy financing in the baseline selected-country model, but the finding is sensitive and does not establish causation. The outcome excludes much domestic and private investment, while the sample and common-slope specification limit generalisation. Future research should assemble broader project expenditure data, distinguish financing sources and technology types, and exploit clearly identified tariff reforms or external supply changes. Until that evidence is available, the paper supports cautious investigation of trade and renewable finance links rather than a claim that openness necessarily increases total clean energy investment.

# Appendix: Individual-Series Stationarity Diagnostics

The ADF null is a unit root. A constant and linear trend are included for trade and transformed financing levels; finance changes include a constant. AIC selects up to two lags. Trade has 1999–2023 observations, finance levels 2000–2023, and finance changes 2001–2023 before lag adjustment. These are short individual-series diagnostics, without multiple-testing adjustment or a cross-sectionally robust panel reference distribution.

All countries contribute 24 observations to the principal regression. The complete ADF statistics, selected lags, and effective counts are in outputs/adf_exploratory.csv. The main-model sample audit, all tested coefficients, and raw source responses are included in the companion reproducibility package.

Table A1. All individual ADF p-values

| Country | Trade ADF p | Finance ADF p | Finance-change ADF p |

| --- | --- | --- | --- |

| BRA | 0.7090 | <0.0001 | <0.0001 |

| CHN | 0.4062 | 0.6334 | <0.0001 |

| IND | 0.7882 | 0.0082 | <0.0001 |

| IDN | 0.0006 | 0.0010 | <0.0001 |

| MEX | 0.0830 | 0.9960 | <0.0001 |

| TUR | 0.9473 | 0.1317 | <0.0001 |

| ZAF | 0.0677 | 0.0045 | <0.0001 |

| THA | 0.0896 | 0.0015 | 0.0004 |

| MYS | 0.7488 | <0.0001 | <0.0001 |

| PHL | 0.8441 | 0.0165 | <0.0001 |

| VNM | 0.3130 | 0.0002 | <0.0001 |

| EGY | 0.3130 | 0.0003 | <0.0001 |

| MAR | 0.0946 | 0.0092 | 0.0002 |

| COL | 0.0184 | 0.0063 | <0.0001 |

| PER | 0.6237 | 0.2956 | 0.0003 |

# References

Antweiler, W., Copeland, B. R., & Taylor, M. S. (2001). Is free trade good for the environment? American Economic Review, 91(4), 877–908. https://doi.org/10.1257/aer.91.4.877

Appiah-Otoo, I., Ampah, J. D., & Chen, X. (2025). Governance, financial openness, and renewable energy investment in Africa. Journal of Policy Modeling, 47(5), 958–976. https://doi.org/10.1016/j.jpolmod.2025.05.003

Cameron, A. C., Gelbach, J. B., & Miller, D. L. (2008). Bootstrap-based improvements for inference with clustered errors. Review of Economics and Statistics, 90(3), 414–427. https://doi.org/10.1162/rest.90.3.414

Copeland, B. R., & Taylor, M. S. (2004). Trade, growth, and the environment. Journal of Economic Literature, 42(1), 7–71. https://doi.org/10.1257/002205104773558047

Driscoll, J. C., & Kraay, A. C. (1998). Consistent covariance matrix estimation with spatially dependent panel data. Review of Economics and Statistics, 80(4), 549–560. https://doi.org/10.1162/003465398557825

Ebaidalla, E. M. (2024). The impact of taxation, technological innovation and trade openness on renewable energy investment: Evidence from the top renewable energy producing countries. Energy, 306, Article 132539. https://doi.org/10.1016/j.energy.2024.132539

Eyraud, L., Clements, B., & Wane, A. (2013). Green investment: Trends and determinants. Energy Policy, 60, 852–865. https://doi.org/10.1016/j.enpol.2013.04.039

Eyraud, L., Zhang, C., Wane, A., & Clements, B. (2011). Who’s going green and why? Trends and determinants of green investment (IMF Working Paper No. 11/296). International Monetary Fund. https://doi.org/10.5089/9781463927301.001

Our World in Data. (n.d.). Energy data [Data set; legacy release]. Retrieved October 12, 2026, from https://github.com/owid/energy-data

Polzin, F., Migendt, M., Täube, F. A., & von Flotow, P. (2015). Public policy influence on renewable energy investments—A panel data study across OECD countries. Energy Policy, 80, 98–111. https://doi.org/10.1016/j.enpol.2015.01.026

United Nations Statistics Division. (n.d.). Global SDG indicators database: Series EG_IFF_RANDN [Data set]. Retrieved October 12, 2026, from https://unstats.un.org/SDGAPI/v1/sdg/Series/Data?seriesCode=EG_IFF_RANDN

United Nations Statistics Division. (2026). SDG indicator 7.a.1: Metadata. https://unstats.un.org/sdgs/metadata/files/Metadata-07-0a-01.pdf

World Bank. (n.d.). World Development Indicators [Data set]. Retrieved October 12, 2026, from https://api.worldbank.org/v2/