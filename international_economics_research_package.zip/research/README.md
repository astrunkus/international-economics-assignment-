# International economics assignment: reproducibility package

**Research question:** Does trade openness encourage clean energy investment? Evidence from emerging markets.

**Operational outcome:** international public financing commitments for clean energy, not all domestic/private investment or disbursements. The principal study covers 15 selected economies, 2000–2023 (360 observations). The source is UN SDG 7.a.1, series `EG_IFF_RANDN`, technology `ALL`, reporting type `G`, millions of constant 2023 US dollars. World Bank population converts commitments to dollars per person. The principal outcome is `ln(1 + real commitments per person)`.

The baseline association is positive (β = 0.1080 for +10 percentage points of lagged openness). Country-clustered inference with a finite-group adjustment and 14 t degrees of freedom gives p = 0.0121. The restricted wild-cluster bootstrap gives p = 0.0734. Recent-period, country-trend and first-difference models do not reject zero at 5%. This is suggestive, sensitive association, not a causal finding about total clean energy investment.

## Files

- `outputs/research_draft.docx`: editable report. Times New Roman 11, 1.5 line spacing, one-inch margins; names/IDs/group placeholders.
- `outputs/research_draft.pdf`: PDF reading copy. Its embedded Liberation Serif font is a metric-compatible substitute for Times New Roman; the requested exact font is specified in DOCX. Confirm rendering in Word with Times New Roman installed before submission.
- `outputs/research_draft.md`: searchable text/tables.
- `data/raw/`: unchanged downloaded responses, source metadata and reference records.
- `data/processed/estimation_panel.csv`: the exact 360-row main sample, all transformations and lags.
- `data/processed/sample_audit.csv`: explicit inclusion flags.
- `data/source_manifest.json`: source URLs, file timestamps and SHA-256 hashes. A hash freezes this local snapshot; it is not a provider's digital signature.
- `outputs/regression_results.csv`: every reported substantive coefficient, SE, p-value, confidence interval, sample size and inference degrees of freedom.
- `outputs/diagnostics.csv`, `adf_exploratory.csv`, `leave_one_country_out.csv`: diagnostic and sensitivity results.
- `outputs/deployment/` and `data/processed/deployment/`: separate solar/wind generation analysis. Generation is not investment. Its original standard package clustered inference is retained separately from the finite-group-adjusted main finance analysis.
- `data/rejected/`: documentation/examples of archived data investigated and rejected as unsuitable for this panel. They are not used by the main model.
- `STATUS.md`: completed work and outstanding author/submission checks.

## Reproduce from the retained data (no network required)

Use the existing checkout. Each cloud task is isolated; do not create a Git worktree unless explicitly requested.

```bash
cd /workspace/international-economics-assignment-/research
python -m venv /workspace/research-venv
/workspace/research-venv/bin/python -m pip install -r requirements.txt
export MPLCONFIGDIR=/tmp/research-mpl
export XDG_CACHE_HOME=/tmp/research-cache
export OPENBLAS_NUM_THREADS=1
/workspace/research-venv/bin/python scripts/analyze.py
/workspace/research-venv/bin/python scripts/build_report.py
/workspace/research-venv/bin/python scripts/validate.py
```

Dependencies are pinned in `requirements.txt`. Package downloads require PyPI access only when dependencies are not already present. The active prepared virtual environment is `/workspace/research-venv`; it does not need recreation for normal use.

To regenerate the supplementary analysis, run `scripts/analyze_deployment.py`. It does not overwrite main finance results. To refresh collection deliberately, preserve the raw snapshot first: collectors reuse existing responses. Run `scripts/collect.py` for World Bank controls and `scripts/collect_finance.py` for UN country responses, then regenerate `scripts/provenance.py`, analysis and the report. Changing source data can change results. Literature scripts retain metadata and available abstracts, not all article full texts.

## Analytical decisions

- The country list and 2000–2023 window were established while collecting controls, before finance coefficients were examined.
- A complete annual grid prevents country lags from crossing missing years.
- `ALL` is not added to technology components. Currency units and the 2023 base period are asserted.
- Thirteen source-reported aggregate zeros are retained; missing values are never filled with zero.
- Country/year fixed effects are compared with pooled and random effects. A clustered Mundlak test assesses the RE orthogonality restriction; no unstable covariance-difference Hausman statistic is substituted.
- The main clustered covariance has a finite-group adjustment; reported t p-values and confidence intervals use G−1 degrees of freedom. Driscoll–Kraay uses package residual degrees of freedom and bandwidth 3; its p-values are an asymptotic sensitivity check.
- The restricted bootstrap uses 9,999 Rademacher draws, seed 311, the explicit dummy model and the finite-cluster covariance formula. It addresses few-country inference, not arbitrary dependence between countries. Its simulated p-value has Monte Carlo uncertainty.
- Individual ADF tests are exploratory. Country-trend and first-difference sensitivity results materially weaken the baseline claim.
- Total-finance robustness uses `ln(1 + commitments in millions)` plus lagged log population; this changes the zero-preserving scale and is not an identical estimand.
- The code checks equality of dummy-OLS and within-estimator point estimates. Validation independently checks unit conversions, inclusion, and key reported results.

## Academic requirements still requiring the group

The slides set a maximum of 20 pages, a 200–300-word abstract with 3–5 keywords, and a 500–700-word conclusion. The generated report checks these quantitative constraints. It also provides a cover/logo, the requested sections, variables/sources, equation, diagnostic results, principal results, discussion and APA-style references.

This paper is an AI-assisted draft. Your course requires less than 30% AI-generated content; a complete AI-written draft does not satisfy that authorship requirement. The group must write and take responsibility for the substantive final prose, verify the analysis, and follow the instructor's rules on assistance. Neither AI-detection percentages nor plagiarism/similarity scores have been measured or guaranteed. Some related studies were reviewed through verified bibliographic metadata and available abstracts; full-text review remains a group task and is explicitly disclosed in the report. Add the student names, IDs and group number before finalising. No email or submission has been sent.
