from pathlib import Path
import json,re,hashlib,numpy as np,pandas as pd,statsmodels.api as sm
from scipy import stats
from pypdf import PdfReader
from docx import Document
R=Path(__file__).resolve().parents[1];O=R/'outputs';results={}
def ok(name,condition):
 assert condition,name
 results[name]='passed'
p=pd.read_csv(R/'data/processed/estimation_panel.csv');s=json.load(open(O/'summary.json'));audit=pd.read_csv(R/'data/processed/sample_audit.csv')
ok('360 unique observations, 15 countries, 24 years',len(p)==360 and p.iso.nunique()==15 and p.year.nunique()==24 and not p.duplicated(['iso','year']).any())
ok('Explicit sample audit has no excluded/missing main rows',len(audit)==360 and audit.included.all() and p[['ln_finance','trade_lag_10','ln_gdppc_lag','fdi_lag']].notna().all().all())
# Independent source-level check across every main-model finance observation.
lookup={}
for f in (R/'data/raw').glob('un_finance_*.json'):
 d=json.load(open(f));ok('UN pagination '+f.stem,d['totalPages']==1 and d['totalElements']==len(d['data']))
 for z in d['data']:
  if z['dimensions']['Type of renewable technology']=='ALL':lookup[(f.stem.split('_')[-1],int(z['timePeriodStart']))]=float(z['value'])
ok('All finance values match raw ALL technology records',all(np.isclose(z.finance_million,lookup[z.iso,z.year]) for z in p.itertuples()))
pop=json.load(open(R/'data/raw/population.json'))[1];pm={(z['countryiso3code'],int(z['date'])):z['value'] for z in pop}
ok('Every denominator matches World Bank population',all(np.isclose(z.population,pm[z.iso,z.year]) for z in p.itertuples()))
ok('Million-dollar to per-person conversion',np.allclose(p.finance_usd_pc,p.finance_million*1e6/p.population))
ok('Log-plus-one conversion and 13 reported zeros',np.allclose(p.ln_finance,np.log1p(p.finance_usd_pc)) and (p.finance_million==0).sum()==13)
trade=json.load(open(R/'data/raw/trade.json'))[1];tm={(z['countryiso3code'],int(z['date'])):z['value'] for z in trade}
ok('All 360 openness lags match prior calendar-year source',all(np.isclose(z.trade_lag_10,tm[z.iso,z.year-1]/10) for z in p.itertuples()))
# Independent dummy OLS / cluster inference, with G-1 t reference.
dummy=pd.get_dummies(p[['iso','year']].astype({'year':str}),drop_first=True,dtype=float);A=np.column_stack([np.ones(len(p)),p[['trade_lag_10','ln_gdppc_lag','fdi_lag']],dummy]);m=sm.OLS(p.ln_finance,A).fit().get_robustcov_results(cov_type='cluster',groups=p.iso,use_correction=True)
ok('Independent dummy-OLS coefficient and corrected cluster SE',np.isclose(m.params[1],s['main_beta'],atol=1e-10) and np.isclose(m.bse[1],s['main_se'],atol=1e-10))
ok('Main p-value uses 14 cluster degrees of freedom',np.isclose(2*stats.t.sf(abs(m.tvalues[1]),14),s['main_p'],atol=1e-10))
rows=pd.read_csv(O/'regression_results.csv');names=rows.model.unique();ok('12 estimated specifications including weakening checks',len(names)==12 and {'FE first differences','FE country trends','FE 2010 onward'}.issubset(names))
ok('45 ADF outcomes and 15 country exclusions',len(pd.read_csv(O/'adf_exploratory.csv'))==45 and len(pd.read_csv(O/'leave_one_country_out.csv'))==15)
b=json.load(open(O/'report_content.json'));wc=lambda t:len(re.findall(r"\b[\w]+(?:[’'-][\w]+)*\b",t))
aw=wc(b[1]['paragraphs'][0]);con=next(x for x in b if x['title'].startswith('5. Conclusion'));cw=wc('\n\n'.join(con['paragraphs']))
ok('Abstract 200–300 words / five keywords',200<=aw<=300 and len(b[1]['paragraphs'][1].split(';'))==5)
ok('Conclusion 500–700 words',500<=cw<=700)
doc=Document(O/'research_draft.docx');st=doc.styles['Normal'];sec=doc.sections[0]
ok('Word body Times New Roman 11 and 1.5 spacing',st.font.name=='Times New Roman' and st.font.size.pt==11 and st.paragraph_format.line_spacing==1.5)
ok('Word normal margins and embedded official logo',all(getattr(sec,n).inches==1 for n in ['top_margin','bottom_margin','left_margin','right_margin']) and len(doc.inline_shapes)==3)
pdf=PdfReader(O/'research_draft.pdf');text='\n'.join(x.extract_text() for x in pdf.pages)
ok('PDF within 20 pages; abstract second and references last',len(pdf.pages)<=20 and 'Abstract' in pdf.pages[1].extract_text() and 'References' in pdf.pages[-1].extract_text())
ok('Reported main and bootstrap values match outputs',f"{s['main_p']:.4f}" in text and f"{s['wild_p']:.4f}" in text and f"{s['main_beta']:.4f}" in text)
manifest=json.load(open(R/'data/source_manifest.json'));ok('Every archived source hash verifies',all(hashlib.sha256((R/x['file']).read_bytes()).hexdigest()==x['sha256'] for x in manifest))
report={'status':'passed','checks':results,'abstract_words':aw,'conclusion_words':cw,'pdf_pages':len(pdf.pages),'limitations':['PDF embeds Liberation Serif; DOCX specifies Times New Roman.','Authorship percentage, similarity/plagiarism score, full-text literature review, and submission are not certified or performed.','Associational evidence covers international public commitments, not total investment expenditure.']}
render=Path('/workspace/lo-render/research_draft.pdf')
if render.exists() and render.stat().st_mtime >= (O/'research_draft.docx').stat().st_mtime:
 report['word_render_pdf_pages']=len(PdfReader(render).pages)
 ok('Fresh independently rendered Word is within 20 pages',report['word_render_pdf_pages']<=20)
(O/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2));print('Checks passed:',len(results))
