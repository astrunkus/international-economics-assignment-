from pathlib import Path
import json,hashlib,datetime
R=Path(__file__).resolve().parents[1]
C=['BRA','CHN','IND','IDN','MEX','TUR','ZAF','THA','MYS','PHL','VNM','EGY','MAR','COL','PER']
ind={'trade':'NE.TRD.GNFS.ZS','gdppc':'NY.GDP.PCAP.KD','fdi':'BX.KLT.DINV.WD.GD.ZS','population':'SP.POP.TOTL','gdp':'NY.GDP.MKTP.CD','inflation':'FP.CPI.TOTL.ZG','energy_ppi':'IE.PPI.ENGY.CD'}
areas=dict(zip(C,[76,156,356,360,484,792,710,764,458,608,704,818,504,170,604]))
urls={f'data/raw/{n}.json':f"https://api.worldbank.org/v2/country/{';'.join(C)}/indicator/{code}?format=json&date=1999:2023&per_page=20000" for n,code in ind.items()}
urls.update({f'data/raw/un_finance_{iso}.json':f'https://unstats.un.org/SDGAPI/v1/sdg/Series/Data?seriesCode=EG_IFF_RANDN&areaCode={code}&pageSize=1000' for iso,code in areas.items()})
urls.update({'data/raw/sdg_7a1_metadata.pdf':'https://unstats.un.org/sdgs/metadata/files/Metadata-07-0a-01.pdf','data/raw/owid-energy-data.csv':'https://raw.githubusercontent.com/owid/energy-data/master/owid-energy-data.csv','data/raw/owid-energy-codebook.csv':'https://raw.githubusercontent.com/owid/energy-data/master/owid-energy-codebook.csv','data/raw/bits_logo.webp':'https://www.bits-pilani.ac.in/wp-content/uploads/bits-pillani-2-1.webp'})
items=[]
for fn,u in urls.items():
 p=R/fn
 if p.exists():items.append({'file':fn,'url':u,'retrieved_utc_from_file_timestamp':datetime.datetime.fromtimestamp(p.stat().st_mtime,datetime.timezone.utc).isoformat(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
for name in ['literature.json','verified_references.json','green_literature.json','method_references.json']:
 p=R/'data/raw'/name
 if p.exists():items.append({'file':str(p.relative_to(R)),'provider':'Crossref API; individual request URLs/DOIs are stored in the response records','sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(R/'data/source_manifest.json').write_text(json.dumps(items,indent=2))
print('Manifest entries:',len(items))
