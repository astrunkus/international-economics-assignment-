from pathlib import Path
import json,numpy as np,pandas as pd,statsmodels.api as sm
from scipy import stats
from linearmodels.panel import PanelOLS,PooledOLS,RandomEffects
from statsmodels.stats.diagnostic import het_breuschpagan
from statsmodels.tsa.stattools import adfuller
from statsmodels.stats.outliers_influence import variance_inflation_factor
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'outputs/deployment';O.mkdir(exist_ok=True);R=ROOT/'data/raw'
C=['BRA','CHN','IND','IDN','MEX','TUR','ZAF','THA','MYS','PHL','VNM','EGY','MAR','COL','PER']
d=pd.MultiIndex.from_product([C,range(1999,2024)],names=['iso','year']).to_frame(index=False)
for name in ['trade','gdppc','fdi','population','gdp','inflation','energy_ppi']:
 raw=json.load(open(R/(name+'.json')))[1]
 a=pd.DataFrame([{'iso':r['countryiso3code'],'year':int(r['date']),name:r['value']} for r in raw])
 assert not a.duplicated(['iso','year']).any()
 d=d.merge(a,on=['iso','year'],how='left',validate='one_to_one')
e=pd.read_csv(R/'owid-energy-data.csv');e=e[e.iso_code.isin(C)&e.year.between(1999,2023)][['iso_code','country','year','solar_electricity','wind_electricity']].rename(columns={'iso_code':'iso'})
d=d.merge(e,on=['iso','year'],validate='one_to_one').sort_values(['iso','year'])
assert len(d)==375 and not d.duplicated(['iso','year']).any()
d['solar_wind_twh']=d.solar_electricity+d.wind_electricity
d['sw_kwh_pc']=d.solar_wind_twh*1e9/d.population
d['ln_sw']=np.log1p(d.sw_kwh_pc);d['ln_gdppc']=np.log(d.gdppc)
d['growth']=d.groupby('iso').ln_sw.diff()
for v in ['trade','ln_gdppc','fdi','ln_sw']:
 d[v+'_lag']=d.groupby('iso')[v].shift(1)
d['trade_lag_10']=d.trade_lag/10
cols=['growth','trade_lag_10','ln_gdppc_lag','fdi_lag']
audit=d[d.year>=2000][['iso','country','year']+cols].copy();audit['included']=audit[cols].notna().all(axis=1)
audit.to_csv(ROOT/'data/processed/deployment/sample_audit.csv',index=False)
d.to_csv(ROOT/'data/processed/deployment/panel_all.csv',index=False)
p=d[d.year>=2000].dropna(subset=cols).set_index(['iso','year'])
p.to_csv(ROOT/'data/processed/deployment/estimation_panel.csv')
xcols=cols[1:];X=sm.add_constant(p[xcols]);y=p.growth
po=PooledOLS(y,X).fit(cov_type='clustered',cluster_entity=True)
fe=PanelOLS(y,X,entity_effects=True,time_effects=True).fit(cov_type='clustered',cluster_entity=True)
dk=PanelOLS(y,X,entity_effects=True,time_effects=True).fit(cov_type='kernel',kernel='bartlett',bandwidth=3)
years=pd.get_dummies(p.index.get_level_values('year'),drop_first=True,dtype=float);years.index=p.index;years.columns=['year_'+str(c) for c in years]
re=RandomEffects(y,pd.concat([X,years],axis=1)).fit(cov_type='clustered',cluster_entity=True)
mx=pd.concat([X,years],axis=1)
for c in xcols:mx['mean_'+c]=p[c].groupby(level=0).transform('mean')
mr=RandomEffects(y,mx).fit(cov_type='clustered',cluster_entity=True)
restr=np.zeros((3,len(mr.params)))
for i,c in enumerate(xcols):restr[i,mr.params.index.get_loc('mean_'+c)]=1
mund=mr.wald_test(restriction=restr)
models={'Pooled (no effects)':po,'Random effects + years':re,'Two-way FE (cluster)':fe,'Two-way FE (DK)':dk}
# Same formula, excluding China, alternative levels, and pre-pandemic period.
p_no=p.loc[p.index.get_level_values('iso')!='CHN'];models['FE excluding China']=PanelOLS(p_no.growth,sm.add_constant(p_no[xcols]),entity_effects=True,time_effects=True).fit(cov_type='clustered',cluster_entity=True)
p_pre=p.loc[p.index.get_level_values('year')<=2019];models['FE through 2019']=PanelOLS(p_pre.growth,sm.add_constant(p_pre[xcols]),entity_effects=True,time_effects=True).fit(cov_type='clustered',cluster_entity=True)
models['FE log deployment level']=PanelOLS(p.ln_sw,X,entity_effects=True,time_effects=True).fit(cov_type='clustered',cluster_entity=True)
# Additional current-income / FDI specification as timing sensitivity.
xc=sm.add_constant(pd.DataFrame({'trade_lag_10':p.trade_lag_10,'ln_gdppc':p.ln_gdppc,'fdi':p.fdi},index=p.index))
models['FE current controls']=PanelOLS(y,xc,entity_effects=True,time_effects=True).fit(cov_type='clustered',cluster_entity=True)
rows=[]
for n,m in models.items():
 for c in m.params.index:
  if c.startswith('year_'):continue
  ci=m.conf_int().loc[c]
  rows.append({'model':n,'variable':c,'coefficient':m.params[c],'se':m.std_errors[c],'t':m.tstats[c],'p':m.pvalues[c],'ci_low':ci.iloc[0],'ci_high':ci.iloc[1],'nobs':m.nobs,'within_r2':getattr(m,'rsquared_within',np.nan)})
pd.DataFrame(rows).to_csv(O/'regression_results.csv',index=False)
# Diagnostics based on explicit dummy OLS; clustered tests where appropriate.
frame=p.reset_index();dummy=pd.get_dummies(frame[['iso','year']].astype({'year':str}),drop_first=True,dtype=float)
A=np.column_stack([np.ones(len(frame)),frame[xcols].to_numpy(),dummy.to_numpy()]);Y=frame.growth.to_numpy();G=frame.iso.to_numpy()
ols=sm.OLS(Y,A).fit();cl=ols.get_robustcov_results(cov_type='cluster',groups=G,use_correction=True)
assert np.isclose(ols.params[1],fe.params['trade_lag_10'],atol=1e-9)
diag=[]
def add(test,stat,pv,interpretation):diag.append({'test':test,'statistic':float(stat),'p_value':float(pv),'interpretation':interpretation})
add('Poolability F (country and year effects jointly)',fe.f_pooled.stat,fe.f_pooled.pval,'Conventional homoskedastic F; supplementary to theoretical choice of FE.')
add('Mundlak country-mean joint Wald (clustered)',mund.stat,mund.pval,'Tests RE orthogonality using country means; FE avoids this restriction.')
bp=het_breuschpagan(ols.resid,sm.add_constant(frame[xcols]));add('Breusch-Pagan heteroskedasticity (exploratory)',bp[0],bp[1],'IID LM reference distribution; use as exploratory in a dependent panel.')
# Wooldridge-style FD serial correlation test: difference all substantive variables and year dummies, no country dummies.
fr=frame.set_index(['iso','year']);fd=fr[['growth']+xcols].groupby(level=0).diff();yd=years.groupby(level=0).diff();fd=fd.join(yd).dropna()
fdres=sm.OLS(fd.growth,fd[xcols+list(yd.columns)]).fit().resid
sr=pd.DataFrame({'resid':fdres});sr['lag']=sr.resid.groupby(level=0).shift();sr=sr.dropna()
smod=sm.OLS(sr.resid,sr[['lag']]).fit(cov_type='cluster',cov_kwds={'groups':sr.index.get_level_values(0),'use_correction':True})
st=float((smod.params.iloc[0]+0.5)/smod.bse.iloc[0]);pv=2*stats.t.sf(abs(st),len(C)-1)
add('FD residual AR(1), H0 coefficient = -0.5',st,pv,'Wooldridge-style test; t reference with 14 cluster degrees of freedom.')
res=fe.resids.unstack(0);corrs=[]
for i in range(len(res.columns)):
 for j in range(i+1,len(res.columns)):
  z=res.iloc[:,[i,j]].dropna();corrs.append(np.sqrt(len(z))*z.corr().iloc[0,1])
cd=np.sqrt(2/(len(C)*(len(C)-1)))*sum(corrs)
add('Pesaran CD residual test (approximate)',cd,2*stats.norm.sf(abs(cd)),'Two-way FE can affect the finite-sample reference; DK is a sensitivity check.')
# VIF after partialling out country/year effects.
D=np.column_stack([np.ones(len(frame)),dummy.to_numpy()]);Z=frame[xcols].to_numpy();Z=Z-D@np.linalg.lstsq(D,Z,rcond=None)[0]
vifs={c:float(variance_inflation_factor(Z,i)) for i,c in enumerate(xcols)}
# Restricted wild cluster bootstrap (Rademacher), explicit FE dummy model, finite-cluster covariance.
Ar=np.delete(A,1,axis=1);fitr=sm.OLS(Y,Ar).fit();base=fitr.fittedvalues;err=fitr.resid
pinv=np.linalg.pinv(A);bread=np.linalg.inv(A.T@A);groups=list(dict.fromkeys(G));idx=[np.flatnonzero(G==g) for g in groups];N,K=A.shape;fac=len(groups)/(len(groups)-1)*(N-1)/(N-K)
def fast_t(v):
 b=pinv@v;r=v-A@b;meat=np.zeros((K,K))
 for ix in idx:
  s=A[ix].T@r[ix];meat+=np.outer(s,s)
 se=np.sqrt((fac*bread@meat@bread)[1,1]);return b[1]/se
rng=np.random.default_rng(311);obs=fast_t(Y);boot=[]
for b in range(999):
 w=rng.choice([-1.,1.],len(groups));v=base+err*np.array([w[groups.index(g)] for g in G]);boot.append(fast_t(v))
bpv=(1+sum(abs(z)>=abs(obs) for z in boot))/1000
add('Wild country-cluster bootstrap trade H0=0',obs,bpv,'999 restricted Rademacher draws, seed 311; finite-cluster check, approximate.')
pd.DataFrame(diag).to_csv(O/'diagnostics.csv',index=False)
adfs=[]
for g,z in d.groupby('iso'):
 for v in ['trade','ln_sw','growth']:
  zz=z[v].dropna()
  try:
   r=adfuller(zz,maxlag=2,regression='ct' if v!='growth' else 'c',autolag='AIC');adfs.append({'iso':g,'variable':v,'statistic':r[0],'p_value':r[1],'lags':r[2],'nobs':r[3]})
  except Exception as e:adfs.append({'iso':g,'variable':v,'error':str(e)})
pd.DataFrame(adfs).to_csv(O/'adf_exploratory.csv',index=False)
loo=[]
for g in C:
 q=p.loc[p.index.get_level_values('iso')!=g];m=PanelOLS(q.growth,sm.add_constant(q[xcols]),entity_effects=True,time_effects=True).fit(cov_type='clustered',cluster_entity=True)
 loo.append({'excluded':g,'beta':m.params['trade_lag_10'],'p':m.pvalues['trade_lag_10']})
pd.DataFrame(loo).to_csv(O/'leave_one_country_out.csv',index=False)
p[['growth','trade_lag','gdppc','fdi','sw_kwh_pc']].describe().T.to_csv(O/'descriptive_statistics.csv')
p.reset_index().groupby(['iso','country']).agg(n=('year','count'),first=('year','min'),last=('year','max')).to_csv(O/'country_coverage.csv')
fig,ax=plt.subplots(figsize=(7,3.4))
for iso in ['CHN','IND','BRA','ZAF','MEX']:
 z=d[d.iso==iso];ax.plot(z.year,z.sw_kwh_pc,label=iso)
ax.set(xlabel='Year',ylabel='Solar + wind generation (kWh/person)',title='Deployment outcomes, not investment expenditure');ax.legend(ncol=5);fig.tight_layout();fig.savefig(O/'deployment_trends.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(7,3.6));names=['Two-way FE (cluster)','FE excluding China','FE through 2019','FE current controls'];rr=pd.DataFrame(rows);r=rr[(rr.variable=='trade_lag_10')&rr.model.isin(names)].set_index('model').loc[names]
ax.errorbar(r.coefficient,range(len(r)),xerr=[r.coefficient-r.ci_low,r.ci_high-r.coefficient],fmt='o',capsize=4);ax.set_yticks(range(len(r)),names);ax.axvline(0,color='grey',linestyle='--');ax.set_xlabel('Change in log deployment growth for +10 pp trade openness');fig.tight_layout();fig.savefig(O/'coefficient_sensitivity.png',dpi=180);plt.close(fig)
summary={'countries':len(C),'candidate_rows':360,'nobs':len(p),'excluded_rows':360-len(p),'period':[int(p.index.get_level_values(1).min()),int(p.index.get_level_values(1).max())],'main_beta':float(fe.params['trade_lag_10']),'main_se':float(fe.std_errors['trade_lag_10']),'main_p':float(fe.pvalues['trade_lag_10']),'main_ci':fe.conf_int().loc['trade_lag_10'].tolist(),'wild_p':bpv,'vif':vifs,'loo_range':[min(r['beta'] for r in loo),max(r['beta'] for r in loo)],'outcome':'Annual change in log(1 + solar/wind electricity generation in kWh/person), NOT clean-energy investment expenditure'}
(O/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2));print(pd.DataFrame(diag).to_string(index=False))
