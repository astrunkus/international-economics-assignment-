from pathlib import Path
import urllib.request,json,hashlib,datetime,concurrent.futures,time
ROOT=Path(__file__).resolve().parents[1]; RAW=ROOT/'data/raw';RAW.mkdir(parents=True,exist_ok=True)
COUNTRIES=['BRA','CHN','IND','IDN','MEX','TUR','ZAF','THA','MYS','PHL','VNM','EGY','MAR','COL','PER']
INDICATORS={'trade':'NE.TRD.GNFS.ZS','gdppc':'NY.GDP.PCAP.KD','fdi':'BX.KLT.DINV.WD.GD.ZS','population':'SP.POP.TOTL','gdp':'NY.GDP.MKTP.CD','inflation':'FP.CPI.TOTL.ZG','energy_ppi':'IE.PPI.ENGY.CD'}
def get(name,url):
 p=RAW/(name+'.json')
 if p.exists():return name,'cached'
 for attempt in range(3):
  try:
   with urllib.request.urlopen(url,timeout=60) as r:b=r.read()
   d=json.loads(b)
   if isinstance(d,list) and (len(d)<2 or not d[1]):raise ValueError('empty World Bank response')
   p.write_bytes(b)
   return name,len(b)
  except Exception as e:
   if attempt==2:return name,str(e)
   time.sleep(2)
urls={n:f"https://api.worldbank.org/v2/country/{';'.join(COUNTRIES)}/indicator/{c}?format=json&date=1999:2023&per_page=20000" for n,c in INDICATORS.items()}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for r in ex.map(lambda x:get(*x),urls.items()):print(r,flush=True)
manifest=[]
for n,u in urls.items():
 p=RAW/(n+'.json')
 if p.exists():manifest.append({'file':str(p.relative_to(ROOT)),'url':u,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(ROOT/'data/source_manifest.json').write_text(json.dumps(manifest,indent=2))
