from pathlib import Path
from docx import Document
import re,json,hashlib
SOURCE=Path('/workspace/attachments/23c1106e-8b74-4d6f-8591-9a553f3013c8/ECON_F311_Enhanced_Research_Paper.docx')
OUT=Path('/workspace/international-economics-assignment-/ECON_F311_Group17_Updated.docx')
d=Document(SOURCE)
students=[('Ritik Yadav','2024B3A30940'),('Sriansh Rajan','2024B3A80901P'),('Nidhish Kumar Tyagi','2024B3A80952P'),('Heet Jain','2024B3A80929P'),('Jaivardhan Singh','2024B3A40859P')]
old=[c.text for row in d.tables[0].rows[1:] for c in row.cells]
def replace_paragraph(p,t):
 assert len(p.runs)==1,'Expected one text run; protect formatting'
 p.runs[0].text=t
assert d.paragraphs[10].text=='Group Number: [7]'
replace_paragraph(d.paragraphs[10],'Group Number: 17')
for row,(name,sid) in zip(d.tables[0].rows[1:],students):
 for cell,text in zip(row.cells,[name,sid]):replace_paragraph(cell.paragraphs[0],text)
edits={
19:'''Can international trade help emerging economies move towards cleaner energy? Access to imported equipment, foreign suppliers and new technology may lower the cost of renewable projects. Trade can also increase electricity demand, support fossil-intensive production and expose investment to external shocks. Both directions are plausible, so the answer depends on the evidence.''',
20:'''Trade can affect both project costs and energy demand. Imported equipment and specialist services may make solar, wind and grid projects cheaper to build. Export growth may raise electricity use, but the additional demand could be met by renewables or by existing fossil technologies. A higher trade-to-GDP ratio therefore does not necessarily mean lower tariffs or more renewable finance. The ratio reflects economic activity as well as policy.''',
21:'''This paper examines that relationship in emerging markets. A practical difficulty is that country-year data often measure renewable capacity, electricity generation or consumption rather than annual investment. These outcomes are not interchangeable. The analysis therefore uses IRENASTAT public renewable-energy finance commitments to capture the public-financing component of clean-energy investment, and sets out what this measure can and cannot tell us.''',
22:'''A public financing commitment is not the same as money spent on a completed project. Development banks, bilateral agencies and other public lenders may approve a large amount before construction or disbursement begins. Project readiness, recipient institutions and donor priorities can influence those decisions. Commitments may therefore follow a different pattern from private spending or installed capacity. The model examines this public-financing relationship, rather than the effect of openness on total realised investment.''',
23:'''The analysis brings together the literature on trade, technology and renewable energy, then combines IRENA finance data with World Bank indicators. Pooled OLS, country fixed-effects and two-way fixed-effects models are compared using clustered inference. The results are interpreted as conditional associations. In the corrected two-way model, the trade coefficient is positive but close to zero and estimated with considerable uncertainty. Neither trade nor inflation is statistically significant, so the results do not establish that greater openness independently raises public renewable-energy finance commitments.''',
39:'''The study contributes in two ways. It uses a stated IMF classification and economic-size rule to select emerging markets, rather than choosing countries without a clear rule. It also distinguishes public renewable-finance commitments from wider measures of clean-energy investment. This makes the outcome easier to interpret, although it narrows the question the data can answer.''',
40:'''A statistical association is not automatically a policy effect. Country characteristics, global shocks, financing cycles and selective data coverage can affect both trade and recorded commitments. Country and year effects address some of these differences; confidence intervals and sensitivity checks show how much uncertainty remains. They do not replace an external instrument or a credible trade-policy experiment. The contribution is a transparent analysis of an investment-related measure, rather than a claim to identify causation.''',
111:'''Once missing finance cells are kept missing, the preferred model gives a trade coefficient close to zero with a wide confidence interval. The data do not reveal a precise association. This does not mean that openness is economically irrelevant. The result concerns public commitments, not the combined private and public spending that creates clean-energy assets.''',
113:'''Several limits matter for interpretation. The outcome leaves out private investment and records commitments rather than actual disbursements. Countries with observed finance data may differ from those with missing entries. Some wind categories may overlap, and their relationship cannot be resolved from this export. Large commitments, donor allocation, changing national policies and reverse causality also complicate the analysis. A longer panel or project-level records would be needed for stronger identification; no causal instrument is claimed here.''',
119:'''Governments should not assume that general trade liberalisation alone will bring in clean-energy finance. If equipment imports face costly delays or transaction costs, improving access to renewable technology is a reasonable step. It still needs to be backed by prepared projects, stable procurement rules, transparent tenders, reliable grids, creditworthy buyers and lenders able to support long-term projects. Better statistics are equally important: commitments, disbursements, private investment and completed capacity should be recorded separately. These distinctions would help policymakers assess whether trade integration leads to working assets, rather than finance that has only been announced.'''
}
# Protect quantitative material and document objects while editing prose.
tables_before=[t._tbl.xml for t in d.tables[1:]]
refs_before=[p._p.xml for p in d.paragraphs[122:]]
images_before=len(d.inline_shapes)
for i,text in edits.items():
 previous=d.paragraphs[i].text
 assert re.findall(r'\d+(?:\.\d+)?',previous)==re.findall(r'\d+(?:\.\d+)?',text),'Numeric content changed'
 replace_paragraph(d.paragraphs[i],text)
d.core_properties.author='; '.join(n for n,i in students)
d.core_properties.last_modified_by='Codex'
d.save(OUT)
r=Document(OUT)
assert [t._tbl.xml for t in r.tables[1:]]==tables_before
assert [p._p.xml for p in r.paragraphs[122:]]==refs_before
assert len(r.inline_shapes)==images_before
all_text='\n'.join(p.text for p in r.paragraphs)+'\n'+'\n'.join(c.text for t in r.tables for row in t.rows for c in row.cells)
assert all(n in all_text and sid in all_text for n,sid in students)
assert not any(x in all_text for x in old)
assert 'Group Number: 17' in all_text
wc=lambda text:len(re.findall(r"\b[\w]+(?:[’'-][\w]+)*\b",text))
abstract_words=wc(r.paragraphs[16].text)
conclusion_words=wc('\n'.join(p.text for p in r.paragraphs[115:121]))
assert 200<=abstract_words<=300
assert 500<=conclusion_words<=700
check={'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'edited_paragraphs':list(edits),'group':17,'student_details_verified':True,'original_names_removed':True,'non_cover_tables_unchanged':True,'references_unchanged':True,'embedded_images_preserved':images_before,'abstract_words':abstract_words,'conclusion_words':conclusion_words,'analysis_independently_verified':False}
Path('/workspace/international-economics-assignment-/research/outputs/uploaded_paper_edit_validation.json').write_text(json.dumps(check,indent=2))
print(json.dumps(check,indent=2));print('Saved:',OUT)
