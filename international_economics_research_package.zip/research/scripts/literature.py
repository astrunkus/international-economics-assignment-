import urllib.request,urllib.parse,json,concurrent.futures
from pathlib import Path
root=Path(__file__).resolve().parents[1]
queries=['Is free trade good for the environment Antweiler Copeland Taylor','Public policy influence on renewable energy investments Polzin Migendt Taube von Flotow','Green investment trends and determinants Eyraud Clements Wane','The impact of taxation technological innovation and trade openness on renewable energy investment Ebaidalla','Governance financial openness renewable energy investment Africa Appiah Otoo','Trade growth and the environment Copeland Taylor']
def fetch(q):
 u='https://api.crossref.org/works?query.bibliographic='+urllib.parse.quote(q)+'&rows=1'
 try:
  with urllib.request.urlopen(u,timeout=40) as r:d=json.load(r)
  a=d['message']['items'][0];return {'query':q,'source_url':u,'record':a}
 except Exception as e:return {'query':q,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:items=list(ex.map(fetch,queries))
(root/'data/raw/literature.json').write_text(json.dumps(items,indent=2))
for a in items:
 r=a.get('record',{});print(r.get('title'),r.get('DOI'),r.get('abstract','')[:2000],flush=True)
