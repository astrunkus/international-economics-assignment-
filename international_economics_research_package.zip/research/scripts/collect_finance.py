from pathlib import Path
import urllib.request,json,concurrent.futures,time
R=Path(__file__).resolve().parents[1]/'data/raw';R.mkdir(exist_ok=True)
areas={'BRA':76,'CHN':156,'IND':356,'IDN':360,'MEX':484,'TUR':792,'ZAF':710,'THA':764,'MYS':458,'PHL':608,'VNM':704,'EGY':818,'MAR':504,'COL':170,'PER':604}
def fetch(item):
 iso,code=item;p=R/('un_finance_'+iso+'.json');u=f'https://unstats.un.org/SDGAPI/v1/sdg/Series/Data?seriesCode=EG_IFF_RANDN&areaCode={code}&pageSize=1000'
 if p.exists():return iso,'cached'
 for k in range(3):
  try:
   with urllib.request.urlopen(u,timeout=75) as r:b=r.read()
   d=json.loads(b);assert d['totalPages']<=1 and len(d['data'])==d['totalElements']
   assert all(str(x['geoAreaCode'])==str(code) for x in d['data'])
   p.write_bytes(b);return iso,d['totalElements']
  except Exception as e:
   if k==2:return iso,str(e)
   time.sleep(2)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for x in ex.map(fetch,areas.items()):print(x,flush=True)
u='https://unstats.un.org/sdgs/metadata/files/Metadata-07-0a-01.pdf'
try:
 with urllib.request.urlopen(u,timeout=45) as r:b=r.read()
 (R/'sdg_7a1_metadata.pdf').write_bytes(b);print('metadata',len(b),flush=True)
except Exception as e:print('metadata',str(e),flush=True)
