import urllib.request,json,concurrent.futures
from pathlib import Path
root=Path(__file__).resolve().parents[1]
dois=['10.1257/aer.91.4.877','10.1016/j.enpol.2015.01.026','10.1016/j.enpol.2013.04.039','10.1016/j.energy.2024.132539','10.1016/j.jpolmod.2025.05.003','10.1257/002205104773558047']
def get(d):
 try:
  u='https://api.crossref.org/works/'+d
  with urllib.request.urlopen(u,timeout=40) as r:a=json.load(r)['message']
  return {'doi':d,'source_url':u,'record':a}
 except Exception as e:return {'doi':d,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:r=list(ex.map(get,dois))
(root/'data/raw/verified_references.json').write_text(json.dumps(r,indent=2))
for a in r:
 b=a.get('record',{});print(a['doi'],b.get('title'),b.get('abstract','')[:1800])
